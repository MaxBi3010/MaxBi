const fs = require("fs");
module.exports.config = {
name: "mp3",
  version: "1.1.1",
  hasPermssion: 0,
  credits: " ",
  description: "no prefix ",
  commandCategory: "noprefix",
  usages: "gõ <mp3> là ra",
  cooldowns: 5,
 dependencies: {
 "request":"",
 "fs-extra":"", 
 "axios":""
 }
};
module.exports.handleEvent = async ({ api, event, Threads }) => {
 if (event.body.indexOf("Mp")==0 || 
event.body.indexOf("mp")==0 ||
event.body.indexOf("mp3 đâu")==0 ||
event.body.indexOf("Mp3 đâu")==0 ||
event.body.indexOf("Mp3")==0 ||
event.body.indexOf("mp3")==0) {
 const axios = global.nodemodule["axios"];
const request = global.nodemodule["request"];
const fs = global.nodemodule["fs-extra"];
 api.sendMessage({body:` Mp3 Nè `, attachment: (await axios.get((await axios.get(`https://sumiproject.io.vn/video/videoanime`)).data.data, {
 responseType: 'stream'
 })).data}, event.threadID, event.messageID);	
 }
 }
module.exports.run = async({api,event,args,Users,Threads,Currencies}) => {

 };