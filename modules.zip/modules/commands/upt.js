const fetch = require('node-fetch');
const os = require('os');
const uptime = os.uptime()

module.exports.config = {
  name: "upt",
  version: "1.0.1",
  hasPermssion: 0,
  credits: "R1zaX",
  description: "no prefix",
  commandCategory: "noprefix",
  usages: "xem thời gian bot onl",
    cooldowns: 5
};

function byte2mb(bytes) {
	const units = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
	let l = 0, n = parseInt(bytes, 10) || 0;
	while (n >= 1024 && ++l) n = n / 1024;
	return `${n.toFixed(n < 10 && l > 0 ? 1 : 0)} ${units[l]}`;
}

module.exports.handleEvent = async ({ api, event, Threads }) => {
const pidusage = await global.nodemodule["pidusage"](process.pid);
  if (!event.body) return;
  var { threadID, messageID } = event;
  const threadname = global.data.threadInfo.get(event.threadID).threadName || ((await Threads.getData(event.threadID)).threadInfo).threadName;
  if (event.body.toLowerCase().indexOf("maxbi") == 0) {
    const dateNow = Date.now();
   const time = process.uptime(),
	      gio = Math.floor(time / (60 * 60)),
	      phut = Math.floor((time % (60 * 60)) / 60),
	    	giay = Math.floor(time % 60);
  const { commands } = global.client;
  const { exec } = require('child_process');
exec('du -sh', (error, stdout, stderr) => {
  if (error) {
    api.sendMessage(`Đã xảy ra lỗi: ${error.message}`, event.threadID, event.messageID);
    return;
  }
  if (stderr) {
    api.sendMessage(`Lỗi STDERR: ${stderr}`, event.threadID, event.messageID);
    return;
  }
  
  const storageUsed = stdout.trim();
  const [size, path] = storageUsed.split('\t');

    api.sendMessage({body:`━━━━[ 𝗨𝗣𝗧𝗜𝗠𝗘 ]━━━━\n\n            ${gio} : ${phut} : ${giay}`},event.threadID, event.messageID);
      });
   }
};

module.exports.run = () => {};