module.exports.config = {
	name: "game", 
	version: "1.0.0",
	hasPermssion: 0,
	credits: "Lâm Hào",
	description: "chơi kéo búa bao",
	commandCategory: "game",
	usages: "[kéo/búa/bao]",
	cooldowns: 5
};

module.exports.run = function({ api, event, args }) {
	//Làm cái gì ở đây tuỳ thuộc vào bạn ¯\_(ツ)_/¯
	let items = {
		"kéo": 0,
		"búa": 1,
		"bao": 2
	}
	if (!Object.keys(items).includes(args[0])) return api.sendMessage("Lựa chọn không hợp lệ", event.threadID);
	let player = items[args[0]];
	let random = Math.floor(Math.random() * 3);
	let bot = Object.values(items)[random];
	let msg = `Bạn chọn: ${args[0]}\nBot chọn: ${Object.keys(items)[random]}\n`;
	if (player == bot) msg += "Hòa";
	else if (player - bot == -2 || player - bot == 1) msg += "Bạn thắng";
	else msg += "Bạn thua";
	return api.sendMessage(msg, event.threadID);
}