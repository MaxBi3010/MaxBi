const axios = require('axios');

module.exports.config = {
  name: "ai",
  version: "1.0.0",
  usePrefix: "false",
  hasPermission: 0,
  credits: "nth",
  description: "ai",
  commandCategory: "AI",
  usages: "<ask>",
  cooldowns: 5,
};

module.exports.run = async function({ api, event, args }) {
  try {
    // Combine the arguments to form the question
    const question = args.join(" ");

    // Check if a question is provided
    if (!question) {
      return api.sendMessage("Vui lòng cung cấp một câu hỏi. Cách sử dụng: .ai [câu hỏi của bạn]", event.threadID, event.messageID);
    }

    api.setMessageReaction("🔍", event.messageID, (err) => {}, true);

    // Make a request to the Thunder AI API
    const apiUrl = 'https://ai-api-s3kj.onrender.com/ai/thunder?question=';
    const response = await axios.get(`${apiUrl}${encodeURIComponent(question)}`);

    // Get the result from the API response
    const answer = response.data.message;

    // Send the answer back to the user

    api.setMessageReaction("", event.messageID, (err) => {}, true);
    api.sendMessage(`${answer}`, event.threadID, event.messageID);
  } catch (error) {
    console.error("error", error.message);
    api.sendMessage("api có vấn đề", event.threadID, event.messageID);
  }
};