module.exports.config = {
	name: "vdanime",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "trunguwu",//chỉ mong mọi người không thay cre:3
	description: "RanDom Video anime",
	commandCategory: "noprefix",
	usages: "anime",
	cooldowns: 0,
	denpendencies: {
		"fs-extra": "",
		"request": ""
		
  }
};
module.exports.handleEvent = async ({ api, event, Threads }) => {
  if (event.body.indexOf("anime")==0 ||
event.body.indexOf("Anime")==0 ) 
//Thay (tên gọi)theo sở thích
//[ Lưu ý !! Không được để trống ( Tên gọi ) 
//Hoặc có thể xoá bớt [event.body.indexOf(")==0 ]
{
    const axios = global.nodemodule["axios"];
const request = global.nodemodule["request"];
const fs = global.nodemodule["fs-extra"];
    var link = [ "https://i.imgur.com/CyIeJB3.mp4",
"https://i.imgur.com/qnw2cZ0.mp4",
"https://i.imgur.com/HT1KZfD.mp4",                
"https://i.imgur.com/nzCEBPm.mp4",
"https://i.imgur.com/qHm1ADM.mp4", 
"https://i.imgur.com/NjIkSy5.mp4",                
"https://i.imgur.com/dYbWD9p.mp4",
"https://i.imgur.com/zB0GFwb.mp4", 
"https://i.imgur.com/tWv3SWK.mp4",               
"https://i.imgur.com/rYQRJsr.mp4",               
"https://i.imgur.com/hRGt3oX.mp4",                
"https://i.imgur.com/iQRgnUb.mp4",               
"https://i.imgur.com/d0cGmv9.mp4",                
"https://i.imgur.com/b6yptSM.mp4",                
"https://i.imgur.com/kuCSoBC.mp4", 
"https://i.imgur.com/GxAVSzZ.mp4",               
"https://i.imgur.com/PINUnFY.mp4",             
"https://i.imgur.com/LC79HLN.mp4", 
 "https://i.imgur.com/YRiYEve.mp4",               
"https://i.imgur.com/LDBflXi.mp4",                
"https://i.imgur.com/dBlCz0O.mp4", 
"https://i.imgur.com/hYAF3y5.mp4",                
"https://i.imgur.com/cFKgjSd.mp4",
"https://i.imgur.com/p5RqKnc.mp4",               
"https://i.imgur.com/nGsaO65.mp4",  
"https://i.imgur.com/1PVRz17.mp4",                
"https://i.imgur.com/JOyOWca.mp4", 
"https://i.imgur.com/KrO9QQS.mp4",               
"https://i.imgur.com/76iHNJh.mp4",                
"https://i.imgur.com/t4DEI2T.mp4",                
"https://i.imgur.com/5040pg3.mp4", 
"https://i.imgur.com/LwY0GV5.mp4",  
"https://i.imgur.com/6maQqMx.mp4",               
"https://i.imgur.com/pll3Pxh.mp4",   
"https://i.imgur.com/w4TLgBm.mp4",               
"https://i.imgur.com/MqEnxJS.mp4", 
"https://i.imgur.com/MoErJJp.mp4", 
"https://i.imgur.com/IG2pLj4.mp4",                
"https://i.imgur.com/PYvkhLR.mp4",              
"https://i.imgur.com/WunUDgo.mp4",               
"https://i.imgur.com/kRzqscm.mp4",  
"https://i.imgur.com/6b6C7BC.mp4", 
"https://i.imgur.com/xErQvMv.mp4",               
"https://i.imgur.com/IGG9gph.mp4", 
"https://i.imgur.com/yCwIh8Z.mp4",                
"https://i.imgur.com/UIkHkRt.mp4", 
"https://i.imgur.com/PR2xIv7.mp4", 
"https://i.imgur.com/t7ncBa9.mp4",              
"https://i.imgur.com/xk6Be3E.mp4",                
"https://i.imgur.com/zCd6Cnl.mp4",                
"https://i.imgur.com/iyscZ7J.mp4",                
"https://i.imgur.com/krhHBDa.mp4",                
"https://i.imgur.com/FGQPi7i.mp4",                
"https://i.imgur.com/ip3aewN.mp4",                
"https://i.imgur.com/MqmDFqI.mp4",
           ];
     var callback = () => api.sendMessage({body:`Anime nè😚`
,attachment: fs.createReadStream(__dirname + "/cache/1.mp4")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/1.mp4"), event.messageID);  
      return request(encodeURI(link[Math.floor(Math.random() * link.length)])).pipe(fs.createWriteStream(__dirname+"/cache/1.mp4")).on("close",() => callback());
}
                                                                                                         }
module.exports.run = async({api,event,args,Users,Threads,Currencies}) => {

   };
   //lỗi gì liên hệ fb https://www.facebook.com/ttrungyeuem207?mibextid=ZbWKwL