module.exports = {
	DeathType: require('./DeathType'),
	Party: require('./Party'),
	State: require('./State')
};
