module.exports = class Movement {
	constructor(ability, value, index, checkerResult) {
		this.ability = ability;
		this.value = value;
		this.index = index;
		this.checkerResult = checkerResult;
	}
};
