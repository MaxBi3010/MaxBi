module.exports.config = {
  name: "ping",
  version: "0.0.3",
  hasPermssion: 1,
  credits: "Mirai Team",
  description: "tag toàn bộ thành viên",
  commandCategory: "Nhóm",
  usages: "[Text]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args, Threads }) { 
  const axios = require('axios');
  const request = require('request');
  const fs = require("fs");
  const moment = require("moment-timezone");
    var gio = moment.tz("Asia/Ho_Chi_Minh").format("D/MM/YYYY || HH:mm:ss");
    var thu = moment.tz('Asia/Ho_Chi_Minh').format('dddd');
  if (thu == 'Sunday') thu = '𝗖𝗵𝘂̉ 𝗻𝗵𝗮̣̂𝘁'
  if (thu == 'Monday') thu = '𝗧𝗵𝘂̛́ 𝟮'
  if (thu == 'Tuesday') thu = '𝗧𝗵𝘂̛́ 𝟯'
  if (thu == 'Wednesday') thu = '𝗧𝗵𝘂̛́ 𝟰'
  if (thu == "Thursday") thu = '𝗧𝗵𝘂̛́ 𝟱'
  if (thu == 'Friday') thu = '𝗧𝗵𝘂̛́ 𝟲'
  if (thu == 'Saturday') thu = '𝗧𝗵𝘂̛́ 𝟳'
const res = await axios.get("https://sumiproject.io.vn/video/videosex");
//lấy data trên web api
const data = res.data.url;
//tải ảnh xuống
let download = (await axios.get(data, {
      responseType: "stream"
    })).data;
  try {
    var all = (await Threads.getInfo(event.threadID)).participantIDs;
    all.splice(all.indexOf(api.getCurrentUserID()), 1);
    all.splice(all.indexOf(event.senderID), 1);
    var body = (args.length != 0) ? args.join(" ") : "𝗗𝗮̣̂𝘆 𝘁𝘂̛𝗼̛𝗻𝗴 𝘁𝗮́𝗰 𝗻𝗮̀𝗼 𝗰𝗮́𝗰 𝗰𝗮̣̂𝘂", mentions = [], index = 0;

    for (let i = 0; i < all.length; i++) {
        if (i == body.length) body += body.charAt(body.length );
        mentions.push({
          tag: body,
          id: all[i],
          fromIndex: i
        });
      }

    return api.sendMessage({ body: `‎📣=====𝗧𝗛𝗢̂𝗡𝗚 𝗕𝗔́𝗢=====📣\n\n𝗛𝗼̂𝗺 𝗻𝗮𝘆 𝗹𝗮̀: ${thu} || ${gio}\n\n${body}`, attachment: download, mentions }, event.threadID, event.messageID);

  }
  catch (e) { return console.log(e); }
}
