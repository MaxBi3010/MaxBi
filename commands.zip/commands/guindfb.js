module.exports.config = {
  name: "sendnd",
  version: "1.0.7",
  hasPermssion: 2,
  credits: "manhG mod by Tiadals", //Vui lòng giữ nguyên credit hoặc ăn đấm !
  description: "Gửi tin hắn đến người dùng(user)/nhóm(thread) bằng ID!",
  commandCategory: "BOT VIP",
  usages: "ID [Text]",
  cooldowns: 5
};

  module.exports.run = async ({ api, event, args }) => {
    const request = global.nodemodule["request"];
   // if (event.senderID != 100022938713167) return api.sendMessage(`[❗] Cúc`, event.threadID, event.messageID)
  const fs = require('fs')
  const axios = require('axios')
  if (args.length == 0) return api.sendMessage("Syntax error, use: sendmsg ID_BOX [lời nhắn]", event.threadID, event.messageID);
  var idbox = args[0];
  var reason = args.slice(1);
    if(reason == "") return api.sendMessage("Syntax error, use: sendmsg ID_BOX [lời nhắn]", event.threadID, event.messageID);
  if (event.type == "message_reply") {
    if(event.messageReply.attachments.length == 0) return api.sendMessage("Yêu cầu reply hình ảnh", event.threadID, event.messageID);
    return request(encodeURI(event.messageReply.attachments[0].url))
      .pipe(fs.createWriteStream(process.cwd()+'/1.png'))
      .on('close',() => 
        api.sendMessage({
          body:`»🍭Thông báo từ thằng admin🐸👍(${api.getCurrentUserID()}) tới  bạn «\nNội dung \n` + reason.join(" "), 
          attachment: fs.createReadStream(process.cwd()+'/1.png')},
          idbox, 
          (err,info) => {
            fs.unlinkSync(process.cwd(), `/1.png`)
            if(err) api.sendMessage("Lỗi: " + err, event.threadID)
              api.sendMessage("Done !!", event.threadID)
          }
        )
      );
  }else {
    return api.sendMessage(`»🍭Thông báo từ Thằng  admin(${api.getCurrentUserID()}) tới  bạn🍭«\n` + reason.join(" "),
      idbox, 
      (err,info) => {
        if(err) api.sendMessage("Lỗi: " + err, event.threadID)
          api.sendMessage("Đã Gửi Tn Cho ló🐸👍 !!", event.threadID)
      }
    )
  }
}
