module.exports ={
	config: {
		name: 'edit',
                version: '1.0.1', 
		credits: 'Lê Minh Tiến',
                hasPermssion: 0,
		usages: 'reply',
		description: 'chỉnh sửa tin nhắn của bot',
                commandCategory: 'Tiện ích',
                images: [], 
		cooldowns: 0
	},
run: async (o) => {
let s = (msg) => o.api.sendMessage(msg, o.event.threadID, o.event.messageID), body = o.event.messageReply.body;
 if (!body || !o.args || o.args.length === 0) return s('Nhập tin nhắn cần chỉnh sửa của bot');
try {
   await o.api.edit(o.args.join(' '), o.event.messageReply.messageID);
    } catch (e) {
      console.error(e);
      s('Phản hồi tin nhắn của bot');
    }
  }
}