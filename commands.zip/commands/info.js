const axios = require('axios');
const fs = require('fs');

module.exports.config = {
  name: "info",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Vtuan",
  description: "Xem thông tin người dùng",
  commandCategory: "Nhóm",
  usages: "[.../tag/reply/id]",
  cooldowns: 0
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  let uid;

  if (args.length > 0) {
    if (args.join().indexOf("@") !== -1) {
      uid = Object.keys(event.mentions)[0];
    } else {
      uid = args[0];
    }
  } else if (event.type === "message_reply") {
    uid = event.messageReply.senderID;
  } else {
    uid = event.senderID;
  }

  try {
    const response = await axios.get(`http://vanthuan.name.vn/facebook/getinfov2?uid=${uid}&apikey=TGUN_4794`);

    if (!response || !response.data) {
      throw new Error('Không có dữ liệu hợp lệ từ API.');
    }

    const avatarURL = `https://graph.facebook.com/${uid}/picture?width=720&height=720&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
    const avatarBuffer = (await axios.get(avatarURL, { responseType: 'arraybuffer' })).data;
    const pathAvt1 = `./modules/commands/cache/${uid}_avt.jpg`;
    fs.writeFileSync(pathAvt1, Buffer.from(avatarBuffer, "utf-8"));

    const latestPost = response.data.posts?.data?.[0];

    const workInfo = response.data.work || [];
    const work0Info = workInfo[0] || {};
    const work1Info = workInfo[1] || {};

    api.sendMessage({
      body: `
== [ Info User] ==
Name: ${response.data.name}
Link profile: ${response.data.link}
Uid: ${response.data.id}
First name: ${response.data.first_name}
Username: ${response.data.username}
Ngày tạo acc: ${response.data.created_time}
Trang web: ${response.data.link}
Giới tính: ${response.data.gender}
Hẹn hò: ${response.data.relationship_status}
Love: ${response.data.love ? response.data.love.name : "Không có thông tin"}
Sinh nhật: ${response.data.birthday === "Sinh nhật private" ? "Không công khai" : response.data.birthday}
Số follower: ${response.data.subscribers?.summary.total_count || "Không có thông tin"}
Tích xanh: ${response.data.tichxanh ? "Có" : "Không có"}
Ngôn ngữ: ${response.data.locale}
Sống ở: ${response.data.location ? response.data.location : "Không công khai"}
Quê hương: ${response.data.hometown ? response.data.hometown : "Không công khai"}
-Công Việc:
+Làm việc tại: ${work0Info.employer?.name || "Không có thông tin"}
+Ngày bắt đầu: ${work0Info.start_date || "Không có thông tin"}
+Bio: ${work1Info.description || "Không có thông tin"}
+Employer: ${work1Info.employer?.name || "Không có thông tin"}
+Vị trí: ${work1Info.position?.name || "Không có thông tin"}
+Chức vụ: ${work1Info.location?.name || "Không có thông tin"}
=== [ Bài đăng mới nhất] ===
Thời gian tạo: ${latestPost?.created_time || "Không có thông tin"}
Nội dung: ${latestPost?.message || "Không có thông tin"}
Link bài đăng: ${latestPost?.actions.find(action => action.name === "Like")?.link || "Không có thông tin"}
      `,
      attachment: fs.createReadStream(pathAvt1)
    }, threadID, messageID);

  } catch (error) {
    console.error('Lỗi khi gửi yêu cầu đến API:', error.message);
    api.sendMessage(`Đã xảy ra lỗi khi gửi yêu cầu đến API.`, threadID, messageID);
  }
}
