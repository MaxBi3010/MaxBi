const linkapi = "https://sumiproject.io.vn/capcutdowload?url=";

module.exports.config = {
    name: "capcut",
    version: "1.0.1",
    hasPermssion: 0,
    credits: "dtai",
    description: "Thông Tin Mẫu Capcut",
    commandCategory: "Tiện ích",
    usages: " +link mẫu capcut",
    cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
    console.log('Bắt đầu tải video capcut!');
};

module.exports.handleEvent = async function ({ api, event, Users }) {
    const { body, senderID } = event;
    const axios = require("axios");
    const fs = require("fs");

    if (
        body === undefined ||
        (!body.includes('https://www.capcut.com/template-detail/') && !body.includes('https://www.capcut.com/t/')) ||
        senderID == api.getCurrentUserID() ||
        senderID == ''
    ) {
        return;
    }

    try {
        var res = await axios.get(`${linkapi}?url=${body}`);
        const title = res.data.title;
        const description = res.data.description;
        const usage = res.data.usage;
        const link = res.data.video;

        const response = await axios.get(link, { responseType: "stream" });
        const stream = response.data;

        api.sendMessage(
            {
                body: `📸==== [ 𝗖𝗔𝗣𝗖𝗨𝗧 ] ====📸
━━━━━━━━━━━━━━━━━
📝 𝗧𝗶𝘁𝗹𝗲: ${title}
😻 𝗠𝗼̂ 𝘁𝗮̉: ${description}
🌸 𝗟𝘂̛𝗼̛̣𝘁 𝗱𝘂̀𝗻𝗴: ${usage}
🧸 𝗟𝗶𝗻𝗸 𝗰𝗮𝗽𝗰𝘂𝘁: ${body}
👉 𝗕𝗮̣𝗻 𝗺𝘂𝗼̂́𝗻 𝗲𝗱𝗶𝘁 𝘃𝗶𝗱𝗲𝗼 𝘁𝗵𝗶̀ 𝗮̂́𝗻 𝘃𝗼̂ 𝗹𝗶𝗻𝗸 𝗰𝗮𝗽𝗰𝘂𝘁 𝗼̛̉ 𝘁𝗿𝗲̂𝗻 đ𝗲̂̉ 𝗲𝗱𝗶𝘁 𝗻𝗵𝗮`,
                attachment: stream,
            },
            event.threadID,
            event.messageID
        );
    } catch (error) {
        console.error(error);
    }
};