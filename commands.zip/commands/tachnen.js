const fs = require('fs');
const axios = require('axios');
const path = require('path');

module.exports.config = {
    name: "tachnen",
    version: "9.0.5",
    hasPermission: 0,
    credits: "Eugene Aguilar",
    description: "Remove background from an image",
    commandCategory: "tools",
    usages: "removebg [reply a photo]",
    cooldowns: 7,
};

module.exports.run = async function ({ api, event, args }) {
    const { sendMessage: reply } = api;
    try {
        let photo;
        if (event.messageReply && event.messageReply.attachments.length > 0) {
            photo = event.messageReply.attachments[0].url;
        } else {
            return reply("⚠️ | Vui lòng trả lời một hình ảnh để xóa nền", event.threadID, event.messageID);
        }

        reply("⏳ | Đang xóa hình nền, vui lòng đợi...", event.threadID, event.messageID);

        const response = await axios.get(`https://eurix-api.replit.app/removebg?input=${encodeURIComponent(photo)}`);
        const imageData = response.data.result.image_data;

        const imageResponse = await axios.get(imageData, { responseType: 'arraybuffer' });
        const image = imageResponse.data;

        const imagePath = path.join(__dirname, "cache", "removebg.png");

        fs.writeFileSync(imagePath, image);

        await reply({ body: "✅ | Đã xóa nền thành công", attachment: fs.createReadStream(imagePath) }, event.threadID, event.messageID);
    } catch (error) {
        reply(`⚠️ | Đã xảy ra lỗi khi xóa nền\n${error}`, event.threadID, event.messageID);
    }
};