const axios = require("axios");
module.exports.config = {
    name: "gai xinh vcl",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "Gấu đẹp trai ",
    description: "noprefix",
    commandCategory: "noprefix",
    usages: "",
    cooldowns: 0,
    denpendencies: {
        "axios": "",
        "moment-timezone": ""
    }
}

module.exports.handleEvent = async ({ event, api,Users }) => {
  const res = await axios.get('https://apibot.dungkon.me/video/girlsexy');
  const data = res.data.url;
  let download = (await axios.get(data, {
      responseType: "stream"
    })).data;
  const moment = require("moment-timezone");
  const hours = moment.tz('Asia/Ho_Chi_Minh').format('HHmm');
  const session = (hours > 2401 && hours <= 400 ? "🧸gái của bạn đây" : hours > 401 && hours <= 700 ? "🧸gái của bạn đây" : hours > 701 && hours <= 1000 ? "🧸gái của bạn đây" : hours > 1001 && hours <= 1200 ? "🧸 gái của bạn đây" : hours > 1201 && hours <= 1700 ? "🧸gái của bạn đây" : hours > 1701 && hours <= 1800 ? "🧸gái của bạn đây" : hours > 1801 && hours <= 2400 ? "🧸 gái của bạn đây" : "🧸gái của bạn đây ")
  let name = await Users.getNameUser(event.senderID)
  var msg = {body: ` ${session}, `, attachment: download}
  if (event.body.toLowerCase() == "gái xinh"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "gái xinh"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "gái cute"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "sexy"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "gái đẹp"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "gai"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "gái"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "gai"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "gái xinh top top"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "gai"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "video gái"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
        };
module.exports.run = async ({ event, api }) => {
return api.sendMessage("𝐃𝐮̀𝐧𝐠 𝐬𝐚𝐢 𝐜𝐚́𝐜𝐡 𝐫𝐨̂̀𝐢 𝐥𝐞̂𝐮 𝐥𝐞̂𝐮",event.threadID)
}